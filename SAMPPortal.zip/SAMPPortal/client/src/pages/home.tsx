import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Gamepad2, 
  Server, 
  Users, 
  Code, 
  Car, 
  Building, 
  Shield, 
  Home, 
  Briefcase, 
  Trophy,
  Newspaper,
  HelpCircle,
  MessageSquare,
  ExternalLink,
  Play,
  Copy,
  Menu,
  Youtube,
  Instagram
} from "lucide-react";
import { SiDiscord } from "react-icons/si";

export default function HomePage() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const copyServerIP = () => {
    navigator.clipboard.writeText('play.azerto.com:7777');
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="fixed top-0 w-full z-50 glass-effect">
        <nav className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 gaming-gradient rounded-lg flex items-center justify-center">
                <Gamepad2 className="text-white text-xl" />
              </div>
              <span className="text-xl font-bold text-glow">Azerto Gaming RPG</span>
            </div>
            
            <div className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('home')}
                className="nav-link hover:text-[var(--gaming-accent)] transition-colors duration-300 relative group"
              >
                Home
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--gaming-accent)] transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button 
                onClick={() => scrollToSection('about')}
                className="nav-link hover:text-[var(--gaming-accent)] transition-colors duration-300 relative group"
              >
                About Us
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--gaming-accent)] transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="nav-link hover:text-[var(--gaming-accent)] transition-colors duration-300 relative group"
              >
                Features
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--gaming-accent)] transition-all duration-300 group-hover:w-full"></span>
              </button>
              <button 
                onClick={() => scrollToSection('forums')}
                className="nav-link hover:text-[var(--gaming-accent)] transition-colors duration-300 relative group"
              >
                Forums
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--gaming-accent)] transition-all duration-300 group-hover:w-full"></span>
              </button>
              <Button className="gaming-gradient hover:shadow-lg hover:shadow-[var(--gaming-accent)]/50 transition-all duration-300 font-semibold">
                Join Server
              </Button>
            </div>
            
            <button className="md:hidden text-white">
              <Menu className="text-xl" />
            </button>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden bg-grid">
        <div className="absolute inset-0 bg-gradient-to-br from-[var(--gaming-primary)] via-[var(--gaming-secondary)] to-[var(--gaming-primary)] opacity-90"></div>
        
        {/* Floating background elements */}
        <motion.div 
          className="absolute top-20 left-10 w-32 h-32 bg-[var(--gaming-accent)]/10 rounded-full animate-float"
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
        <motion.div 
          className="absolute bottom-20 right-10 w-24 h-24 bg-[var(--gaming-cyan)]/10 rounded-full animate-float"
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity, delay: 1 }}
        />
        <motion.div 
          className="absolute top-1/2 left-1/4 w-16 h-16 bg-[var(--gaming-neon)]/10 rounded-full animate-float"
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 3, repeat: Infinity, delay: 2 }}
        />
        
        <div className="container mx-auto px-6 text-center relative z-10">
          <motion.div 
            className="mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-6 relative">
              <span className="gaming-gradient-text text-glow">
                AZERTO GAMING
              </span>
            </h1>
            <h2 className="text-2xl md:text-4xl font-semibold text-gray-300 mb-4">
              Ultimate SAMP Experience
            </h2>
            <p className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Join the most immersive San Andreas Multiplayer server with custom scripts, 
              epic roleplay scenarios, and an amazing community.
            </p>
          </motion.div>
          
          {/* Server Stats */}
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-accent)]/20 hover:border-[var(--gaming-accent)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-[var(--gaming-accent)] mb-2">247</div>
                <div className="text-sm text-gray-400">Players Online</div>
              </CardContent>
            </Card>
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-cyan)]/20 hover:border-[var(--gaming-cyan)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-[var(--gaming-cyan)] mb-2">500</div>
                <div className="text-sm text-gray-400">Max Slots</div>
              </CardContent>
            </Card>
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-neon)]/20 hover:border-[var(--gaming-neon)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-[var(--gaming-neon)] mb-2">99.9%</div>
                <div className="text-sm text-gray-400">Uptime</div>
              </CardContent>
            </Card>
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-accent)]/20 hover:border-[var(--gaming-accent)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-[var(--gaming-accent)] mb-2">24/7</div>
                <div className="text-sm text-gray-400">Support</div>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* CTA Buttons */}
          <motion.div 
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <Button className="gaming-gradient px-8 py-4 rounded-xl hover:shadow-xl hover:shadow-[var(--gaming-accent)]/30 transition-all duration-300 font-semibold text-lg animate-glow">
              <Play className="mr-2" />
              Connect Now
            </Button>
            <Button variant="outline" className="border-2 border-[var(--gaming-accent)]/50 px-8 py-4 rounded-xl hover:bg-[var(--gaming-accent)]/10 hover:border-[var(--gaming-accent)] transition-all duration-300 font-semibold text-lg">
              <SiDiscord className="mr-2" />
              Join Discord
            </Button>
          </motion.div>
          
          {/* Server IP */}
          <motion.div 
            className="mt-8 p-4 bg-[var(--gaming-secondary)]/30 rounded-lg inline-block"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <span className="text-gray-400">Server IP: </span>
            <span className="font-mono text-[var(--gaming-accent)] font-semibold">play.azerto.com:7777</span>
            <button 
              onClick={copyServerIP}
              className="ml-2 text-[var(--gaming-cyan)] hover:text-white transition-colors"
            >
              <Copy className="w-4 h-4" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-[var(--gaming-secondary)]/30">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-glow">About Azerto Gaming RPG</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Since 2020, we've been delivering the ultimate SAMP experience with custom features, 
              dedicated staff, and a thriving community of roleplay enthusiasts.
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <img 
                src="https://images.unsplash.com/photo-1542273917363-3b1817f69a2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Gaming server infrastructure" 
                className="rounded-xl shadow-2xl shadow-[var(--gaming-accent)]/20 w-full h-auto"
              />
            </motion.div>
            
            <motion.div 
              className="space-y-6"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
            >
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 gaming-gradient rounded-lg flex items-center justify-center flex-shrink-0">
                  <Server className="text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">High Performance Servers</h3>
                  <p className="text-gray-400">Dedicated hardware ensuring lag-free gameplay and 99.9% uptime for uninterrupted gaming sessions.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-[var(--gaming-cyan)] to-[var(--gaming-neon)] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Users className="text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Active Community</h3>
                  <p className="text-gray-400">Join thousands of players in immersive roleplay scenarios with professional moderation and support.</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-[var(--gaming-neon)] to-[var(--gaming-accent)] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Code className="text-white" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Custom Scripts</h3>
                  <p className="text-gray-400">Unique gameplay mechanics, custom vehicles, businesses, and features you won't find anywhere else.</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-glow">Server Features</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Experience the most comprehensive SAMP server with features designed for ultimate roleplay immersion.
            </p>
          </motion.div>
          
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, staggerChildren: 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-accent)]/20 hover:border-[var(--gaming-accent)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-accent)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 gaming-gradient rounded-lg flex items-center justify-center mb-4">
                  <Car className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Custom Vehicles</h3>
                <p className="text-gray-400">Over 200 custom vehicles including supercars, motorcycles, boats, and aircraft with realistic handling.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-cyan)]/20 hover:border-[var(--gaming-cyan)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-cyan)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-[var(--gaming-cyan)] to-[var(--gaming-neon)] rounded-lg flex items-center justify-center mb-4">
                  <Building className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Business System</h3>
                <p className="text-gray-400">Own and operate various businesses including restaurants, shops, gas stations, and entertainment venues.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-neon)]/20 hover:border-[var(--gaming-neon)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-neon)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-[var(--gaming-neon)] to-[var(--gaming-accent)] rounded-lg flex items-center justify-center mb-4">
                  <Shield className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Law Enforcement</h3>
                <p className="text-gray-400">Join LSPD, FBI, or SWAT with realistic police procedures, equipment, and patrol systems.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-accent)]/20 hover:border-[var(--gaming-accent)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-accent)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 gaming-gradient rounded-lg flex items-center justify-center mb-4">
                  <Home className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Property System</h3>
                <p className="text-gray-400">Buy, sell, and customize houses and apartments with furniture, security systems, and garages.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-cyan)]/20 hover:border-[var(--gaming-cyan)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-cyan)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-[var(--gaming-cyan)] to-[var(--gaming-neon)] rounded-lg flex items-center justify-center mb-4">
                  <Briefcase className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Job System</h3>
                <p className="text-gray-400">Choose from 20+ realistic jobs including taxi driver, mechanic, doctor, lawyer, and more.</p>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-neon)]/20 hover:border-[var(--gaming-neon)]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[var(--gaming-neon)]/20">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-[var(--gaming-neon)] to-[var(--gaming-accent)] rounded-lg flex items-center justify-center mb-4">
                  <Trophy className="text-white text-2xl" />
                </div>
                <h3 className="text-xl font-semibold mb-3">Events & Competitions</h3>
                <p className="text-gray-400">Regular tournaments, races, and special events with exclusive rewards and prizes.</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Forums Section */}
      <section id="forums" className="py-20 bg-[var(--gaming-secondary)]/30">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-glow">Community Forums</h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Connect with fellow players, share experiences, get support, and stay updated with the latest server news.
            </p>
          </motion.div>
          
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-accent)]/20 hover:border-[var(--gaming-accent)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Newspaper className="text-[var(--gaming-accent)] text-2xl mr-3" />
                  <h3 className="text-xl font-semibold">Server News</h3>
                </div>
                <p className="text-gray-400 mb-4">Stay updated with the latest server updates, events, and announcements from our development team.</p>
                <div className="text-sm text-[var(--gaming-cyan)]">245 posts • 1.2k views</div>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-cyan)]/20 hover:border-[var(--gaming-cyan)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <HelpCircle className="text-[var(--gaming-cyan)] text-2xl mr-3" />
                  <h3 className="text-xl font-semibold">Support Center</h3>
                </div>
                <p className="text-gray-400 mb-4">Get help with technical issues, account problems, or general questions from our support team.</p>
                <div className="text-sm text-[var(--gaming-cyan)]">892 posts • 5.6k views</div>
              </CardContent>
            </Card>
            
            <Card className="bg-[var(--gaming-secondary)]/50 glass-effect border-[var(--gaming-neon)]/20 hover:border-[var(--gaming-neon)]/50 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <MessageSquare className="text-[var(--gaming-neon)] text-2xl mr-3" />
                  <h3 className="text-xl font-semibold">General Discussion</h3>
                </div>
                <p className="text-gray-400 mb-4">Chat with the community about gameplay, share screenshots, and discuss roleplay scenarios.</p>
                <div className="text-sm text-[var(--gaming-cyan)]">3.2k posts • 15.8k views</div>
              </CardContent>
            </Card>
          </motion.div>
          
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <Button 
              className="gaming-gradient px-8 py-4 rounded-xl hover:shadow-xl hover:shadow-[var(--gaming-accent)]/30 transition-all duration-300 font-semibold text-lg"
              onClick={() => window.open('https://azertogamingrpg.flarum.cloud/', '_blank')}
            >
              <ExternalLink className="mr-2" />
              Visit Forums
            </Button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-[var(--gaming-primary)] border-t border-[var(--gaming-accent)]/20">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-8">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 gaming-gradient rounded-lg flex items-center justify-center">
                  <Gamepad2 className="text-white text-xl" />
                </div>
                <span className="text-xl font-bold text-glow">Azerto Gaming RPG</span>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed">
                The ultimate San Andreas Multiplayer experience with custom features, 
                active community, and professional management since 2020.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-[var(--gaming-accent)]">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><button onClick={() => scrollToSection('home')} className="text-gray-400 hover:text-white transition-colors">Home</button></li>
                <li><button onClick={() => scrollToSection('about')} className="text-gray-400 hover:text-white transition-colors">About Us</button></li>
                <li><button onClick={() => scrollToSection('features')} className="text-gray-400 hover:text-white transition-colors">Features</button></li>
                <li><button onClick={() => scrollToSection('forums')} className="text-gray-400 hover:text-white transition-colors">Forums</button></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-[var(--gaming-cyan)]">Support</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Rules & Guidelines</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Ban Appeals</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Bug Reports</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white transition-colors">Contact Staff</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4 text-[var(--gaming-neon)]">Connect</h4>
              <div className="flex space-x-4">
                <a href="#" className="w-10 h-10 bg-[var(--gaming-secondary)]/50 rounded-lg flex items-center justify-center hover:bg-[var(--gaming-accent)]/20 transition-colors">
                  <SiDiscord className="text-gray-400 hover:text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-[var(--gaming-secondary)]/50 rounded-lg flex items-center justify-center hover:bg-[var(--gaming-accent)]/20 transition-colors">
                  <Youtube className="text-gray-400 hover:text-white" />
                </a>
                <a href="#" className="w-10 h-10 bg-[var(--gaming-secondary)]/50 rounded-lg flex items-center justify-center hover:bg-[var(--gaming-accent)]/20 transition-colors">
                  <Instagram className="text-gray-400 hover:text-white" />
                </a>
              </div>
              <div className="mt-4 text-sm">
                <div className="text-gray-400">Server IP:</div>
                <div className="font-mono text-[var(--gaming-accent)]">play.azerto.com:7777</div>
              </div>
            </div>
          </div>
          
          <div className="border-t border-[var(--gaming-accent)]/20 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 Azerto Gaming RPG. All rights reserved. | Privacy Policy | Terms of Service</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
